public class Global {
    public static Cart cart = new Cart();
    public static Wishlist wishlist = new Wishlist();
    public static History history = new History();
    public static Movie[] movie = new Movie[75];
    public static int currentNumOfMovies = 0;
}
